Thank you for downloading my Voicebank!!!

My Voicebank has a Voicebank of 13 characters.

- Abby
- Angry Abby
- Auditor
- Deimos
- Duck
- Hank
- Jebus
- New Agoti
- Old Lord X
- Rasazy
- Sanford
- Selever
- Soul BF

*IMPORTANT*
If you use my Voicebank, please leave a link to GitHub (my Voicebank) or my YouTube channel!!